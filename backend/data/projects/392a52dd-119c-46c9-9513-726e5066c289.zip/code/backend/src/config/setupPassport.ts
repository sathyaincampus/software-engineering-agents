export default () => {
    console.log('Passport configuration loaded (strategies are typically imported and used in routes).');
};
